#!/bin/bash

./wizard.exe "C:\Users\mttffr\AppData\Local\Programs\Arizona Games Launcher\bin\arizona" world.cadb
