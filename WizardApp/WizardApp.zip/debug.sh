#!/bin/bash

(cd build && gdb -x commands.txt ./wizard)
